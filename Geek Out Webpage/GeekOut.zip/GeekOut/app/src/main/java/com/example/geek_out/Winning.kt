package com.example.geek_out
import android.app.Activity
import android.os.Bundle

class Winning: Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.winninguser)
        //need to set the winning user in the textview
    }
}